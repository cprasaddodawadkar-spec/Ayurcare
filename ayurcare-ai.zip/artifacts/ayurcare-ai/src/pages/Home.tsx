import { useState } from "react";
import { useGetRemedy, useGetWellnessTip } from "@workspace/api-client-react";
import { Sparkles, Leaf, Info, Apple, Activity, AlertTriangle, ArrowRight, RefreshCw, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const [problem, setProblem] = useState("");
  const { data: wellnessTip } = useGetWellnessTip();
  const getRemedyMutation = useGetRemedy();

  const handleSearch = () => {
    if (!problem.trim()) return;
    getRemedyMutation.mutate({ data: { problem } });
  };

  const handleReset = () => {
    setProblem("");
    getRemedyMutation.reset();
  };

  const isLoading = getRemedyMutation.isPending;
  const isSuccess = getRemedyMutation.isSuccess;
  const response = getRemedyMutation.data;

  return (
    <div className="flex-1 flex flex-col">
      {/* Hero Section */}
      <section className="relative px-4 py-16 md:py-24 max-w-4xl mx-auto w-full flex flex-col items-center justify-center text-center">
        
        {/* Background decorative blob */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[120%] bg-secondary/5 rounded-[100%] blur-3xl -z-10 pointer-events-none" />

        <Badge variant="outline" className="mb-6 px-4 py-1.5 text-sm font-medium border-primary/20 text-primary/80 bg-primary/5 rounded-full">
          <Leaf className="w-3.5 h-3.5 mr-2 inline-block" />
          Your Ayurvedic Companion
        </Badge>
        
        <h1 className="text-4xl md:text-6xl font-serif font-semibold tracking-tight text-foreground mb-6">
          Natural wisdom for <br className="hidden md:block" />
          <span className="text-primary italic">everyday wellness</span>
        </h1>
        
        <p className="text-lg text-muted-foreground max-w-2xl mb-10 leading-relaxed">
          Describe what you're feeling. AyurCare AI references ancient traditional practices to suggest herbs, diet, and lifestyle changes to restore your balance.
        </p>

        {!isSuccess && (
          <div className="w-full max-w-2xl bg-card rounded-2xl shadow-xl shadow-primary/5 border border-border/50 p-2 sm:p-4 overflow-hidden animate-in fade-in zoom-in-95 duration-500">
            <Textarea
              placeholder="e.g., I have a bad cold with a sore throat, or my lower back joints hurt after sitting..."
              className="min-h-[120px] resize-none border-0 focus-visible:ring-0 shadow-none text-lg p-4 bg-transparent placeholder:text-muted-foreground/60"
              value={problem}
              onChange={(e) => setProblem(e.target.value)}
              disabled={isLoading}
              data-testid="input-problem"
            />
            <div className="flex justify-between items-center px-4 pb-2 pt-4 border-t border-border/50">
              <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                Be specific for better results
              </p>
              <Button 
                onClick={handleSearch} 
                disabled={isLoading || !problem.trim()}
                size="lg"
                className="rounded-full px-8"
                data-testid="button-get-remedy"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Get Remedy
                  </>
                )}
              </Button>
            </div>
          </div>
        )}

        {/* Initial Empty State / Wellness Tip */}
        {!isLoading && !isSuccess && wellnessTip && (
          <div className="mt-16 w-full max-w-2xl text-left animate-in slide-in-from-bottom-4 fade-in duration-700 delay-200 fill-mode-both">
            <h3 className="text-sm font-semibold tracking-wider uppercase text-muted-foreground mb-4">Tip of the day</h3>
            <Card className="bg-primary/5 border-primary/10 hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <p className="text-lg text-foreground/90 font-serif leading-relaxed">"{wellnessTip.tip}"</p>
                {wellnessTip.herbs.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {wellnessTip.herbs.map((herb) => (
                      <Badge key={herb} variant="secondary" className="bg-white/50 dark:bg-black/20 text-xs">
                        {herb}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </section>

      {/* Results Section */}
      {isSuccess && response && (
        <section className="flex-1 bg-muted/20 pb-20 pt-8 animate-in slide-in-from-bottom-8 fade-in duration-700">
          <div className="container max-w-5xl mx-auto px-4">
            
            <div className="flex items-center justify-between mb-8">
              <Button 
                variant="ghost" 
                onClick={handleReset}
                className="text-muted-foreground hover:text-foreground group"
                data-testid="button-reset-search"
              >
                <RefreshCw className="mr-2 h-4 w-4 group-hover:-rotate-180 transition-transform duration-500" />
                Try another problem
              </Button>
            </div>

            {!response.matched && response.generalWellness && (
              <div className="mb-8 p-6 bg-secondary/10 border border-secondary/20 rounded-xl flex items-start gap-4">
                <Info className="h-6 w-6 text-secondary shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-lg mb-1">No exact match found</h3>
                  <p className="text-muted-foreground">We couldn't pinpoint a specific condition for your description. However, here are some general wellness practices that might help.</p>
                </div>
              </div>
            )}

            {response.remedy && (
              <div className="space-y-6">
                <div className="mb-10 text-center">
                  <h2 className="text-3xl md:text-4xl font-serif font-semibold text-primary mb-3">
                    {response.remedy.condition}
                  </h2>
                  <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                    {response.remedy.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Home Remedies */}
                  <Card className="md:col-span-2 shadow-sm border-primary/10">
                    <CardHeader className="bg-primary/5 pb-4">
                      <CardTitle className="flex items-center gap-2 text-xl font-serif">
                        <Sparkles className="h-5 w-5 text-primary" />
                        Traditional Remedies
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <ul className="space-y-4">
                        {response.remedy.remedies.map((remedy, i) => (
                          <li key={i} className="flex items-start gap-3">
                            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-medium shrink-0 mt-0.5">
                              {i + 1}
                            </span>
                            <span className="text-foreground/90 leading-relaxed">{remedy}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Herbs */}
                  <Card className="shadow-sm">
                    <CardHeader className="pb-3 border-b border-border/50">
                      <CardTitle className="flex items-center gap-2 text-lg font-serif">
                        <Leaf className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                        Suggested Herbs
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-5">
                      <div className="flex flex-wrap gap-2">
                        {response.remedy.herbs.map((herb, i) => (
                          <Badge key={i} variant="secondary" className="px-3 py-1 text-sm font-medium">
                            {herb}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Diet */}
                  <Card className="shadow-sm">
                    <CardHeader className="pb-3 border-b border-border/50">
                      <CardTitle className="flex items-center gap-2 text-lg font-serif">
                        <Apple className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                        Dietary Advice
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-5">
                      <ul className="space-y-3">
                        {response.remedy.diet.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-foreground/80">
                            <ArrowRight className="h-4 w-4 text-amber-500/50 shrink-0 mt-1" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Lifestyle */}
                  <Card className="shadow-sm">
                    <CardHeader className="pb-3 border-b border-border/50">
                      <CardTitle className="flex items-center gap-2 text-lg font-serif">
                        <Activity className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                        Lifestyle & Dinacharya
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-5">
                      <ul className="space-y-3">
                        {response.remedy.lifestyle.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-foreground/80">
                            <ArrowRight className="h-4 w-4 text-blue-500/50 shrink-0 mt-1" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Precautions */}
                  <Card className="shadow-sm bg-destructive/5 border-destructive/20">
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2 text-lg font-serif text-destructive">
                        <AlertTriangle className="h-5 w-5" />
                        Precautions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-3">
                        {response.remedy.precautions.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-destructive/80 font-medium">
                            <div className="w-1.5 h-1.5 rounded-full bg-destructive/50 shrink-0 mt-2" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
}
