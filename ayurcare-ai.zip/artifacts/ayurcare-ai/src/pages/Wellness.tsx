import { useGetWellnessTip } from "@workspace/api-client-react";
import { Sun, Leaf, Droplets, Calendar, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Wellness() {
  const { data: wellnessTip, isLoading } = useGetWellnessTip();

  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <Badge variant="outline" className="mb-4 px-3 py-1 border-secondary/30 text-secondary-foreground bg-secondary/10">
          <Sun className="w-3.5 h-3.5 mr-2 inline-block" />
          Daily Wisdom
        </Badge>
        <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">Wellness & Dinacharya</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Ayurveda emphasizes daily routines (Dinacharya) and seasonal adaptations to maintain harmony between mind, body, and environment.
        </p>
      </div>

      {isLoading ? (
        <div className="w-full h-64 bg-card rounded-2xl animate-pulse mb-12 border border-border/50"></div>
      ) : wellnessTip ? (
        <Card className="mb-16 border-none shadow-xl bg-gradient-to-br from-primary/10 via-background to-secondary/5 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
            <Sparkles className="w-32 h-32" />
          </div>
          
          <CardContent className="p-8 md:p-12 relative z-10">
            <div className="flex items-center gap-2 text-primary font-medium tracking-wide uppercase text-sm mb-6">
              <Calendar className="w-4 h-4" />
              <span>Today's Focus: {wellnessTip.category}</span>
            </div>
            
            <p className="text-2xl md:text-3xl font-serif text-foreground/90 leading-relaxed mb-8">
              "{wellnessTip.tip}"
            </p>
            
            {wellnessTip.herbs.length > 0 && (
              <div>
                <p className="text-sm text-muted-foreground mb-3 font-medium">Allies for today:</p>
                <div className="flex flex-wrap gap-2">
                  {wellnessTip.herbs.map((herb) => (
                    <Badge key={herb} className="bg-primary hover:bg-primary/90 text-primary-foreground px-4 py-1.5 text-sm">
                      <Leaf className="w-3 h-3 mr-2 inline-block opacity-70" />
                      {herb}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ) : null}

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="bg-card hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-950 flex items-center justify-center mb-4">
              <Sun className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
            <h3 className="font-serif text-xl font-medium mb-2">Morning Routine</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Wake up before sunrise (Brahma Muhurta). Drink warm water with lemon to stimulate digestion. Scrape your tongue to remove toxins.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center mb-4">
              <Leaf className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
            </div>
            <h3 className="font-serif text-xl font-medium mb-2">Mindful Eating</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Eat your largest meal at noon when digestive fire (Agni) is strongest. Eat in a calm environment without digital distractions.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-950 flex items-center justify-center mb-4">
              <Droplets className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="font-serif text-xl font-medium mb-2">Evening Wind Down</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Eat a light dinner before 7 PM. Dim the lights, practice gentle yoga or meditation, and aim to sleep by 10 PM.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
