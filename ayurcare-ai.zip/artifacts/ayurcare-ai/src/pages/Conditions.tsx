import { useState, useEffect } from "react";
import { useGetConditions, useSearchConditions, getSearchConditionsQueryKey } from "@workspace/api-client-react";
import { Search, Info, Leaf } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Conditions() {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(searchQuery), 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const { data: allConditionsData, isLoading: isLoadingAll } = useGetConditions();
  
  const { data: searchResultsData, isLoading: isLoadingSearch } = useSearchConditions(
    { q: debouncedQuery },
    { 
      query: { 
        enabled: debouncedQuery.length > 0,
        queryKey: getSearchConditionsQueryKey({ q: debouncedQuery })
      } 
    }
  );

  const isSearching = debouncedQuery.length > 0;
  const conditions = isSearching 
    ? searchResultsData?.conditions 
    : allConditionsData?.conditions;

  const isLoading = isSearching ? isLoadingSearch : isLoadingAll;

  return (
    <div className="container max-w-6xl mx-auto px-4 py-12">
      <div className="mb-12 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-serif font-bold text-foreground mb-4">Ayurvedic Knowledge Base</h1>
        <p className="text-muted-foreground text-lg">
          Browse traditional remedies and approaches for common health conditions.
        </p>
      </div>

      <div className="max-w-xl mx-auto mb-12 relative">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
          <Input
            type="search"
            placeholder="Search conditions (e.g. cold, stress, digestion)..."
            className="w-full pl-12 pr-4 py-6 text-lg rounded-full shadow-sm border-border/60 focus-visible:border-primary focus-visible:ring-primary/20 bg-card"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search-conditions"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-card h-48 rounded-xl border border-border/50"></div>
          ))}
        </div>
      ) : (
        <>
          {conditions && conditions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {conditions.map((condition) => (
                <Card 
                  key={condition.id} 
                  className="group hover:shadow-md hover:border-primary/30 transition-all duration-300 overflow-hidden"
                  data-testid={`card-condition-${condition.id}`}
                >
                  <CardHeader className="bg-muted/30 group-hover:bg-primary/5 transition-colors pb-4">
                    <CardTitle className="font-serif text-xl text-foreground group-hover:text-primary transition-colors">
                      {condition.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-2 mb-3 text-sm text-muted-foreground">
                      <Info className="h-4 w-4" />
                      <span>Associated keywords:</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {condition.keywords.map((keyword, i) => (
                        <Badge key={i} variant="outline" className="font-normal bg-background/50">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-muted/20 rounded-2xl border border-border border-dashed">
              <Leaf className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-xl font-medium text-foreground mb-2">No conditions found</h3>
              <p className="text-muted-foreground">We couldn't find any conditions matching "{debouncedQuery}"</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
