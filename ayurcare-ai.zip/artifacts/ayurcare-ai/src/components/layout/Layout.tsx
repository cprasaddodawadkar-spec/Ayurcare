import { Header } from "./Header";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/20">
      <Header />
      <main className="flex-1 flex flex-col relative z-0">
        {children}
      </main>
      <footer className="border-t py-8 mt-auto bg-muted/30">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p className="mb-2">Disclaimer: AyurCare AI provides traditional knowledge for educational purposes only.</p>
          <p>Always consult a qualified Ayurvedic practitioner before starting any new treatment.</p>
        </div>
      </footer>
    </div>
  );
}
