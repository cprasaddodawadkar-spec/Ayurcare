import { Link, useLocation } from "wouter";
import { Leaf, Moon, Sun } from "lucide-react";
import { useTheme } from "@/components/theme-provider";
import { Button } from "@/components/ui/button";

export function Header() {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity" data-testid="link-home">
          <Leaf className="h-6 w-6" />
          <span className="font-serif text-xl font-semibold tracking-tight">AyurCare AI</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          <Link 
            href="/" 
            className={`text-sm font-medium transition-colors hover:text-primary ${location === "/" ? "text-primary" : "text-muted-foreground"}`}
            data-testid="nav-home"
          >
            Remedy Search
          </Link>
          <Link 
            href="/conditions" 
            className={`text-sm font-medium transition-colors hover:text-primary ${location === "/conditions" ? "text-primary" : "text-muted-foreground"}`}
            data-testid="nav-conditions"
          >
            Conditions
          </Link>
          <Link 
            href="/wellness" 
            className={`text-sm font-medium transition-colors hover:text-primary ${location === "/wellness" ? "text-primary" : "text-muted-foreground"}`}
            data-testid="nav-wellness"
          >
            Daily Wellness
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            data-testid="button-toggle-theme"
            className="rounded-full"
          >
            {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
