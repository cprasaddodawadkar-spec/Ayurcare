import { Router, type IRouter, type Request, type Response } from "express";
import { conditions, generalWellness, wellnessTips } from "../data/ayurveda";

const router: IRouter = Router();

function computeMatchScore(problem: string, keywords: string[]): number {
  const normalizedProblem = problem.toLowerCase().trim();
  let score = 0;
  let maxKeywordLen = 0;

  for (const keyword of keywords) {
    const kw = keyword.toLowerCase();
    if (normalizedProblem.includes(kw)) {
      const kwWeight = kw.split(" ").length;
      score += kwWeight;
      if (kw.length > maxKeywordLen) maxKeywordLen = kw.length;
    }
  }

  if (score === 0) return 0;
  const normalized = Math.min(score / (keywords.length * 0.5), 1);
  return Math.round(normalized * 100) / 100;
}

router.post("/remedy", (req: Request, res: Response) => {
  const { problem } = req.body as { problem?: string };

  if (!problem || typeof problem !== "string" || problem.trim().length === 0) {
    res.status(400).json({ error: "problem field is required" });
    return;
  }

  let bestMatch = null;
  let bestScore = 0;

  for (const condition of conditions) {
    const score = computeMatchScore(problem, condition.keywords);
    if (score > bestScore) {
      bestScore = score;
      bestMatch = condition;
    }
  }

  const MATCH_THRESHOLD = 0.05;

  if (bestMatch && bestScore >= MATCH_THRESHOLD) {
    res.json({
      matched: true,
      remedy: {
        condition: bestMatch.name,
        description: bestMatch.description,
        remedies: bestMatch.remedies,
        herbs: bestMatch.herbs,
        diet: bestMatch.diet,
        lifestyle: bestMatch.lifestyle,
        precautions: bestMatch.precautions,
        matchScore: bestScore,
      },
    });
  } else {
    res.json({
      matched: false,
      generalWellness: {
        condition: generalWellness.name,
        description: generalWellness.description,
        remedies: generalWellness.remedies,
        herbs: generalWellness.herbs,
        diet: generalWellness.diet,
        lifestyle: generalWellness.lifestyle,
        precautions: generalWellness.precautions,
        matchScore: 0,
      },
    });
  }
});

router.get("/conditions", (_req: Request, res: Response) => {
  const result = conditions.map((c) => ({
    id: c.id,
    name: c.name,
    keywords: c.keywords,
  }));
  res.json({ conditions: result });
});

router.get("/wellness", (_req: Request, res: Response) => {
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) /
      (1000 * 60 * 60 * 24)
  );
  const tip = wellnessTips[dayOfYear % wellnessTips.length];
  res.json(tip);
});

router.get("/search", (req: Request, res: Response) => {
  const q = (req.query.q as string || "").toLowerCase().trim();

  if (!q) {
    res.json({ conditions: [] });
    return;
  }

  const results = conditions.filter(
    (c) =>
      c.name.toLowerCase().includes(q) ||
      c.keywords.some((kw) => kw.toLowerCase().includes(q)) ||
      c.description.toLowerCase().includes(q)
  );

  res.json({
    conditions: results.map((c) => ({
      id: c.id,
      name: c.name,
      keywords: c.keywords,
    })),
  });
});

export default router;
