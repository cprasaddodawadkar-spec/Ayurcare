import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ayurvedaRouter from "./ayurveda";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/ayurveda", ayurvedaRouter);

export default router;
