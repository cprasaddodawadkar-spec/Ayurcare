export interface AyurvedaCondition {
  id: string;
  name: string;
  keywords: string[];
  description: string;
  remedies: string[];
  herbs: string[];
  diet: string[];
  lifestyle: string[];
  precautions: string[];
}

export const conditions: AyurvedaCondition[] = [
  {
    id: "cold",
    name: "Common Cold",
    keywords: ["cold", "runny nose", "sneezing", "nasal", "congestion", "stuffy", "rhinitis", "sniffle"],
    description: "The common cold is an upper respiratory tract infection caused by viruses. Ayurveda attributes it to Kapha imbalance with Vata involvement.",
    remedies: [
      "Drink warm ginger-tulsi tea 2-3 times daily",
      "Inhale steam with a few drops of eucalyptus oil",
      "Mix 1 tsp honey with a pinch of black pepper and consume twice daily",
      "Gargle with warm salt water 3 times a day",
      "Apply warm sesame oil inside nostrils (Nasya)"
    ],
    herbs: ["Tulsi (Holy Basil)", "Ginger (Adrak)", "Turmeric (Haldi)", "Black Pepper (Kali Mirch)", "Licorice (Mulethi)"],
    diet: [
      "Drink warm soups, broths, and herbal teas",
      "Eat light, easily digestible foods like khichdi",
      "Include garlic and ginger in meals",
      "Avoid cold, raw, or heavy foods",
      "Stay well hydrated with warm water"
    ],
    lifestyle: [
      "Rest adequately and avoid strenuous activity",
      "Keep warm, especially the head and neck",
      "Practice Pranayama (breathing exercises) like Nadi Shodhana",
      "Oil massage with warm sesame oil (Abhyanga)",
      "Avoid exposure to cold wind and air conditioning"
    ],
    precautions: [
      "Consult a doctor if symptoms persist beyond 7-10 days",
      "Watch for signs of secondary infection (fever, colored mucus)",
      "Avoid sharing utensils or close contact with others",
      "Do not suppress natural urges like sneezing or coughing"
    ]
  },
  {
    id: "cough",
    name: "Cough",
    keywords: ["cough", "coughing", "throat", "hoarse", "sore throat", "phlegm", "mucus", "tickle throat", "dry cough", "wet cough"],
    description: "Cough in Ayurveda (Kasa) is primarily a Kapha or Vata disorder affecting the respiratory tract. It can be dry or productive.",
    remedies: [
      "Mix 1 tsp of ginger juice with honey and consume slowly",
      "Chew a small piece of licorice root or make tea from it",
      "Warm milk with turmeric and a pinch of black pepper",
      "Prepare a decoction of Tulsi leaves, ginger, and black pepper",
      "Inhale steam with camphor or eucalyptus oil"
    ],
    herbs: ["Licorice (Mulethi)", "Tulsi", "Ginger", "Turmeric", "Vasaka (Malabar Nut)", "Pippali (Long Pepper)"],
    diet: [
      "Drink warm herbal teas and broths frequently",
      "Avoid cold drinks, ice cream, and refrigerated food",
      "Include honey in your diet as a natural throat soother",
      "Eat warm, cooked foods only",
      "Avoid dairy products as they can increase mucus"
    ],
    lifestyle: [
      "Avoid exposure to dust, smoke, and strong odors",
      "Practice steam inhalation 1-2 times daily",
      "Sleep with your head slightly elevated",
      "Avoid talking excessively when throat is irritated",
      "Maintain good indoor humidity levels"
    ],
    precautions: [
      "See a doctor if cough lasts more than 2-3 weeks",
      "Blood in cough requires immediate medical attention",
      "Avoid cough suppressants that interfere with natural clearing",
      "Monitor for fever or breathing difficulty"
    ]
  },
  {
    id: "fever",
    name: "Fever",
    keywords: ["fever", "temperature", "hot", "burning", "pyrexia", "chills", "sweating", "feverish"],
    description: "Fever (Jwara) in Ayurveda is considered the king of diseases and typically involves Pitta aggravation. The body uses heat to fight infections.",
    remedies: [
      "Drink tulsi and ginger tea with honey",
      "Apply sandalwood paste on the forehead for cooling",
      "Drink a decoction of giloy (Guduchi) stem",
      "Sponge the body with room-temperature water",
      "Prepare a decoction of coriander seeds and drink warm"
    ],
    herbs: ["Giloy (Guduchi/Tinospora)", "Tulsi", "Neem", "Chirayta", "Coriander (Dhania)"],
    diet: [
      "Drink plenty of warm fluids — water, herbal teas, coconut water",
      "Eat light, easily digestible foods like rice gruel or khichdi",
      "Avoid heavy, oily, or spicy foods",
      "Include pomegranate juice or watermelon for hydration",
      "Fasting or semi-fasting can help the body recover"
    ],
    lifestyle: [
      "Rest completely — physical activity worsens fever",
      "Keep the room well-ventilated but not too cold",
      "Change sweat-soaked clothing frequently",
      "Avoid strong light and stimulation",
      "Practice light breathing exercises when comfortable"
    ],
    precautions: [
      "Seek immediate care for fever above 103°F (39.4°C)",
      "High fever in children requires urgent medical attention",
      "Never give aspirin to children with fever",
      "Watch for stiff neck, severe headache, or confusion"
    ]
  },
  {
    id: "acidity",
    name: "Acidity & Heartburn",
    keywords: ["acidity", "heartburn", "acid reflux", "gerd", "burning", "stomach acid", "indigestion burn", "chest burn", "acid"],
    description: "Acidity (Amlapitta) is caused by excess Pitta dosha in the stomach. Modern diet and stress are major contributors.",
    remedies: [
      "Drink a glass of cold milk or a teaspoon of ghee in warm milk",
      "Chew on raw amla (Indian gooseberry) or take amla powder",
      "Eat a banana or a small piece of coconut to neutralize acid",
      "Drink coconut water on an empty stomach",
      "Mix 1 tsp of shatavari powder in warm milk and drink at night"
    ],
    herbs: ["Amla (Indian Gooseberry)", "Shatavari", "Yashtimadhu (Licorice)", "Triphala", "Fennel (Saunf)"],
    diet: [
      "Eat small, frequent meals at regular intervals",
      "Avoid spicy, sour, fried, and fermented foods",
      "Include cooling foods: cucumber, coconut, pomegranate",
      "Chew fennel seeds after meals",
      "Avoid tea, coffee, alcohol, and carbonated drinks"
    ],
    lifestyle: [
      "Do not lie down immediately after eating — wait 2-3 hours",
      "Eat dinner at least 3 hours before bedtime",
      "Practice Sheetali pranayama (cooling breath)",
      "Manage stress through meditation and yoga",
      "Avoid tight clothing around the abdomen"
    ],
    precautions: [
      "Persistent acid reflux may indicate GERD — consult a doctor",
      "Do not take antacids excessively without medical guidance",
      "Blood in vomit or stool requires immediate attention",
      "Watch weight as obesity worsens acid reflux"
    ]
  },
  {
    id: "indigestion",
    name: "Indigestion",
    keywords: ["indigestion", "bloating", "gas", "flatulence", "stomach", "upset stomach", "dyspepsia", "heaviness", "belching", "burping"],
    description: "Indigestion (Ajirna) occurs when Agni (digestive fire) is weak. Ayurveda considers strong digestion central to all health.",
    remedies: [
      "Drink warm ginger tea before meals to stimulate digestion",
      "Take a pinch of hing (asafoetida) in warm water",
      "Chew a small piece of ginger with rock salt before meals",
      "Prepare Jeera (cumin) water and sip throughout the day",
      "Take Triphala churna with warm water at bedtime"
    ],
    herbs: ["Ginger (Adrak)", "Cumin (Jeera)", "Asafoetida (Hing)", "Ajwain (Carom Seeds)", "Triphala"],
    diet: [
      "Eat only when genuinely hungry",
      "Chew food thoroughly and eat slowly",
      "Avoid overeating — eat to 75% capacity",
      "Include digestive spices: cumin, coriander, fennel, ginger",
      "Avoid incompatible food combinations (e.g., milk with fish)"
    ],
    lifestyle: [
      "Take a short walk (15-20 min) after meals",
      "Practice Vajrasana (thunderbolt pose) after eating",
      "Avoid eating when emotionally stressed",
      "Maintain regular meal times",
      "Avoid heavy meals close to bedtime"
    ],
    precautions: [
      "Chronic indigestion warrants a medical evaluation",
      "Sudden severe stomach pain needs urgent care",
      "Avoid self-medicating with laxatives long-term",
      "Rule out underlying conditions like IBS or H. pylori"
    ]
  },
  {
    id: "constipation",
    name: "Constipation",
    keywords: ["constipation", "bowel", "stool", "hard stool", "irregular", "straining", "difficult bowel", "no motion", "constipated"],
    description: "Constipation (Vibandha) reflects aggravated Vata dosha and weakened digestive fire. Regular, easy bowel movements are a cornerstone of Ayurvedic health.",
    remedies: [
      "Take 1-2 tsp of castor oil with warm milk at bedtime",
      "Drink warm water with lemon on an empty stomach each morning",
      "Soak raisins overnight and eat them in the morning",
      "Take Triphala churna with warm water before bed",
      "Eat 2-3 figs soaked overnight in warm water"
    ],
    herbs: ["Triphala", "Senna (Sanay)", "Castor Oil (Erand)", "Isabgol (Psyllium Husk)", "Haritaki"],
    diet: [
      "Increase fiber intake: fruits, vegetables, whole grains",
      "Stay well hydrated — drink at least 8-10 glasses of water daily",
      "Include prunes, figs, and papaya in your diet",
      "Add ghee to food to lubricate the intestines",
      "Avoid processed, refined, and dry foods"
    ],
    lifestyle: [
      "Establish a regular morning routine for bowel movements",
      "Do not suppress the urge to defecate",
      "Practice yoga asanas: Pavanamuktasana, Malasana, Trikonasana",
      "Exercise daily for at least 30 minutes",
      "Manage stress through meditation"
    ],
    precautions: [
      "Consult a doctor if constipation is sudden or severe",
      "Blood in stool requires immediate medical evaluation",
      "Avoid long-term dependence on laxatives",
      "Rule out hypothyroidism or other underlying conditions"
    ]
  },
  {
    id: "hair-fall",
    name: "Hair Fall",
    keywords: ["hair fall", "hair loss", "baldness", "thinning hair", "alopecia", "shedding hair", "bald", "hair thinning"],
    description: "Hair fall (Khalitya) in Ayurveda is primarily a Pitta and Vata disorder. Hormonal imbalances, stress, and poor nutrition are major causes.",
    remedies: [
      "Massage scalp with warm Bhringraj oil weekly",
      "Apply a paste of amla, shikakai, and coconut oil to hair",
      "Mix onion juice with coconut oil and apply to scalp",
      "Drink amla juice or eat fresh amla daily",
      "Apply aloe vera gel directly to the scalp"
    ],
    herbs: ["Bhringraj", "Amla (Amalaki)", "Brahmi", "Neem", "Ashwagandha"],
    diet: [
      "Eat iron-rich foods: leafy greens, legumes, sesame seeds",
      "Include protein-rich foods: lentils, eggs, dairy, nuts",
      "Consume biotin-rich foods: nuts, seeds, eggs",
      "Add zinc-rich foods: pumpkin seeds, chickpeas",
      "Avoid excess spicy, sour, and oily foods"
    ],
    lifestyle: [
      "Reduce stress through yoga and meditation — stress is a major cause",
      "Avoid excessive heat styling and chemical treatments",
      "Use gentle, natural shampoos and conditioners",
      "Practice inversion yoga poses to improve scalp circulation",
      "Get adequate sleep — hair grows during rest"
    ],
    precautions: [
      "Sudden severe hair loss may indicate a medical condition",
      "Get thyroid levels and iron levels tested",
      "Avoid extremely tight hairstyles",
      "Patch test all topical treatments before full application"
    ]
  },
  {
    id: "dandruff",
    name: "Dandruff",
    keywords: ["dandruff", "flaky scalp", "scalp flakes", "seborrhea", "itchy scalp", "dry scalp", "white flakes"],
    description: "Dandruff (Darunaka) involves aggravated Vata and Kapha doshas affecting the scalp, leading to dry, flaky skin.",
    remedies: [
      "Apply neem oil mixed with coconut oil to the scalp",
      "Use a paste of fenugreek seeds soaked overnight",
      "Rinse hair with apple cider vinegar diluted in water",
      "Apply lemon juice to the scalp 15 minutes before washing",
      "Use a shikakai and reetha hair wash"
    ],
    herbs: ["Neem", "Fenugreek (Methi)", "Bhringraj", "Tea Tree", "Amla"],
    diet: [
      "Reduce sugar and refined carbohydrates in your diet",
      "Include omega-3 fatty acids: flaxseeds, walnuts, fish",
      "Stay hydrated to prevent dry scalp",
      "Reduce intake of dairy if prone to fungal issues",
      "Eat probiotic foods to balance gut health"
    ],
    lifestyle: [
      "Wash hair regularly but not excessively",
      "Avoid scratching the scalp as it worsens inflammation",
      "Manage stress, which can trigger dandruff flare-ups",
      "Use a wide-toothed comb to avoid scalp damage",
      "Expose scalp to gentle morning sunlight occasionally"
    ],
    precautions: [
      "Severe or persistent dandruff may indicate seborrheic dermatitis",
      "Consult a dermatologist if scalp is red, painful, or oozing",
      "Avoid sharing combs or hats",
      "Test for contact dermatitis from hair products"
    ]
  },
  {
    id: "stress",
    name: "Stress",
    keywords: ["stress", "stressed", "overwhelmed", "tension", "pressure", "burnout", "mental burden", "overworked", "worried"],
    description: "Stress (Chinta) causes Vata and Pitta aggravation in Ayurveda. Chronic stress depletes Ojas (vital essence) and disrupts all bodily functions.",
    remedies: [
      "Practice Ashwagandha root powder with warm milk at night",
      "Practice Shirodhara at home with warm oil over the forehead",
      "Take regular oil massages (Abhyanga) with sesame or Brahmi oil",
      "Drink Brahmi tea or take Brahmi supplement daily",
      "Practice progressive muscle relaxation before bed"
    ],
    herbs: ["Ashwagandha", "Brahmi (Bacopa)", "Shatavari", "Shankhpushpi", "Jatamansi"],
    diet: [
      "Eat warm, nourishing, grounding foods — soups, stews",
      "Avoid caffeine, alcohol, and processed foods which worsen stress",
      "Include magnesium-rich foods: dark chocolate, nuts, leafy greens",
      "Eat regular meals at fixed times",
      "Warm milk with ashwagandha and honey before bed"
    ],
    lifestyle: [
      "Practice yoga daily — especially restorative and grounding poses",
      "Meditate for 10-20 minutes daily",
      "Maintain a consistent daily routine (Dinacharya)",
      "Spend time in nature and sunlight",
      "Limit screen time, especially before bed"
    ],
    precautions: [
      "Chronic stress can lead to serious mental health conditions",
      "Seek professional help for severe anxiety or depression",
      "Do not self-medicate with alcohol or substances",
      "Build a social support network"
    ]
  },
  {
    id: "anxiety",
    name: "Anxiety",
    keywords: ["anxiety", "anxious", "panic", "worried", "nervous", "fear", "restless", "racing heart", "panic attack"],
    description: "Anxiety (Chittodvega) in Ayurveda is a Vata disorder affecting the mind. It involves excess movement and instability in the nervous system.",
    remedies: [
      "Take Brahmi and Ashwagandha supplement combination",
      "Practice warm sesame oil massage on the scalp and feet",
      "Drink warm milk with a pinch of nutmeg before bed",
      "Practice Nadi Shodhana pranayama (alternate nostril breathing)",
      "Chant mantras or listen to calming ragas"
    ],
    herbs: ["Brahmi", "Ashwagandha", "Jatamansi", "Shankhpushpi", "Tagara (Indian Valerian)"],
    diet: [
      "Eat warm, cooked, and grounding foods",
      "Avoid stimulants: caffeine, energy drinks, alcohol",
      "Include sweet, sour, and salty tastes to calm Vata",
      "Eat at regular times to create stability",
      "Warm sesame or almond milk with spices before bed"
    ],
    lifestyle: [
      "Establish a strict, calming daily routine",
      "Practice grounding yoga asanas: forward bends, Shavasana",
      "Journal thoughts to externalize worries",
      "Limit news and social media consumption",
      "Spend time in warm, quiet, familiar environments"
    ],
    precautions: [
      "Seek professional help for severe or debilitating anxiety",
      "Do not abruptly stop prescribed anxiety medications",
      "Anxiety with chest pain needs cardiac evaluation",
      "Keep a support person informed of your struggles"
    ]
  },
  {
    id: "insomnia",
    name: "Insomnia & Sleep Problems",
    keywords: ["insomnia", "sleep", "sleepless", "cant sleep", "waking up", "poor sleep", "sleep disorder", "tired but awake"],
    description: "Insomnia (Anidra) is primarily a Vata disorder with possible Pitta involvement. Ayurveda emphasizes sleep as one of the three pillars of health.",
    remedies: [
      "Drink warm milk with ashwagandha and a pinch of nutmeg before bed",
      "Apply Brahmi oil to the scalp and feet before sleep",
      "Take a warm bath with calming essential oils (lavender, sandalwood)",
      "Practice Yoga Nidra (yogic sleep meditation)",
      "Massage feet with warm sesame oil before sleeping"
    ],
    herbs: ["Ashwagandha", "Brahmi", "Jatamansi", "Tagara (Indian Valerian)", "Shatavari"],
    diet: [
      "Eat a light, warm dinner 2-3 hours before bed",
      "Avoid caffeine after noon",
      "Include tryptophan-rich foods: warm milk, bananas, dates",
      "Reduce alcohol — it disrupts sleep quality",
      "Have a small warm drink like golden milk at bedtime"
    ],
    lifestyle: [
      "Maintain a consistent sleep and wake schedule",
      "Create a dark, cool, quiet sleep environment",
      "Avoid screens 1 hour before bed",
      "Do light yoga or stretching in the evening",
      "Follow Dinacharya — synchronized daily routine"
    ],
    precautions: [
      "Chronic insomnia needs professional evaluation",
      "Sleep apnea (snoring with pauses) requires medical care",
      "Avoid sleep medications without medical guidance",
      "Mental health conditions often underlie insomnia"
    ]
  },
  {
    id: "joint-pain",
    name: "Joint Pain & Arthritis",
    keywords: ["joint pain", "arthritis", "joint ache", "knee pain", "back pain", "stiff joints", "rheumatism", "inflammation joint", "osteoarthritis"],
    description: "Joint pain (Sandhivata) is primarily a Vata disorder in Ayurveda, often with Ama (toxins) accumulation in the joints.",
    remedies: [
      "Apply warm sesame or Mahanarayan oil and massage the joint",
      "Make a paste of turmeric and ginger in mustard oil for topical application",
      "Drink a glass of warm water with turmeric and black pepper",
      "Take Shallaki (Boswellia) supplement for anti-inflammatory effects",
      "Apply castor oil poultice on the affected joint"
    ],
    herbs: ["Shallaki (Boswellia)", "Guggulu", "Turmeric", "Ginger", "Rasna", "Ashwagandha"],
    diet: [
      "Follow an anti-inflammatory diet: fresh vegetables, fruits",
      "Include omega-3 fatty acids: walnuts, flaxseeds",
      "Avoid nightshades (tomatoes, eggplant, peppers) — aggravate Vata",
      "Reduce processed foods, sugar, and fried foods",
      "Include warm soups and stews for nourishment"
    ],
    lifestyle: [
      "Practice gentle yoga and low-impact exercises daily",
      "Avoid overexertion and extreme cold exposure",
      "Apply warm oil packs (Pinda Sweda) to affected joints",
      "Maintain healthy weight to reduce joint load",
      "Practice Panchakarma detox seasonally if possible"
    ],
    precautions: [
      "Sudden severe joint pain needs immediate medical care",
      "Do not ignore progressive loss of function",
      "Gout attacks require specific medical management",
      "Autoimmune arthritis (RA) needs rheumatologist care"
    ]
  },
  {
    id: "weight-loss",
    name: "Weight Loss (Underweight)",
    keywords: ["weight loss", "underweight", "thin", "low weight", "gain weight", "too thin", "malnourished", "weak"],
    description: "Being underweight (Karshya) involves deficient Kapha and Mamsa (muscle tissue). Ayurveda focuses on nourishing all seven dhatus (tissues).",
    remedies: [
      "Take Ashwagandha with warm milk and sugar",
      "Consume dates soaked in ghee regularly",
      "Drink Shatavari kalpa (Shatavari in milk and sugar) daily",
      "Eat small, frequent, nourishing meals throughout the day",
      "Have Chyawanprash daily in warm milk"
    ],
    herbs: ["Ashwagandha", "Shatavari", "Chyawanprash", "Vidari Kanda", "Bala"],
    diet: [
      "Eat calorie-dense, nourishing foods: nuts, seeds, dairy, ghee",
      "Include protein at every meal: lentils, paneer, eggs, meat",
      "Eat healthy fats: ghee, coconut oil, avocado, nuts",
      "Have 5-6 small meals throughout the day",
      "Drink high-calorie smoothies with banana, dates, nuts, and milk"
    ],
    lifestyle: [
      "Practice strength-building yoga asanas",
      "Avoid excessive cardio which burns too many calories",
      "Reduce stress which impairs absorption",
      "Get adequate sleep for anabolic (building) processes",
      "Eat in a calm, pleasant environment"
    ],
    precautions: [
      "Unexplained weight loss requires medical investigation",
      "Rule out malabsorption, thyroid, or diabetes",
      "Do not try to gain weight too rapidly",
      "Ensure weight gain is from muscle, not just fat"
    ]
  },
  {
    id: "weight-gain",
    name: "Weight Gain (Obesity)",
    keywords: ["weight gain", "obesity", "overweight", "fat", "lose weight", "reduce weight", "heavy", "obese"],
    description: "Excess weight (Sthoulya) involves excess Kapha dosha and Ama accumulation. Ayurveda emphasizes kindling Agni and reducing Kapha.",
    remedies: [
      "Drink warm water with lemon and honey every morning",
      "Take Triphala churna with warm water at bedtime",
      "Drink Guggulu tea to stimulate metabolism",
      "Consume ginger-lemon water throughout the day",
      "Take Medohar Guggulu as directed"
    ],
    herbs: ["Guggulu", "Triphala", "Turmeric", "Ginger", "Kutki (Picrorhiza)", "Vrikshamla (Garcinia)"],
    diet: [
      "Eat light, warm, and spiced foods to increase Agni",
      "Avoid heavy, sweet, fried, and processed foods",
      "Reduce portion sizes and eat only when hungry",
      "Include bitter and pungent tastes: bitter gourd, fenugreek",
      "Avoid snacking between meals — let digestion complete"
    ],
    lifestyle: [
      "Practice vigorous exercise: walking, yoga, swimming",
      "Sun salutations (Surya Namaskar) daily are very effective",
      "Dry massage (Udvartana) with herbal powder",
      "Maintain regular meal times and avoid late-night eating",
      "Reduce sedentary behavior — stand and move regularly"
    ],
    precautions: [
      "Consult a doctor before starting any weight loss program",
      "Crash diets are unhealthy — lose weight gradually",
      "Medical weight gain may need hormonal evaluation",
      "Emotional eating requires behavioral support"
    ]
  },
  {
    id: "diabetes",
    name: "Diabetes (Basic Guidance)",
    keywords: ["diabetes", "blood sugar", "glucose", "diabetic", "sugar level", "hyperglycemia", "prediabetes"],
    description: "Diabetes (Madhumeha) is classified as a Kapha disorder in Ayurveda, though all doshas are involved. Note: This is general wellness guidance only — always follow your doctor's advice.",
    remedies: [
      "Drink bitter gourd (karela) juice in the morning",
      "Consume fenugreek seed water (soaked overnight) daily",
      "Take Vijaysar bark water — a traditional Ayurvedic remedy",
      "Use turmeric with black pepper in cooking daily",
      "Consume cinnamon regularly in food or as tea"
    ],
    herbs: ["Bitter Gourd (Karela)", "Fenugreek (Methi)", "Turmeric", "Gurmar (Gymnema)", "Vijaysar", "Neem"],
    diet: [
      "Follow a low glycemic index diet",
      "Avoid sugar, white rice, bread, and processed carbohydrates",
      "Include fiber-rich foods: vegetables, legumes, whole grains",
      "Eat small, frequent balanced meals",
      "Include bitter vegetables: karela, methi leaves"
    ],
    lifestyle: [
      "Exercise regularly — even 30 min walking helps blood sugar",
      "Monitor blood sugar levels as prescribed",
      "Practice stress management — stress spikes blood sugar",
      "Maintain healthy weight",
      "Get regular medical check-ups"
    ],
    precautions: [
      "This is general guidance only — always follow your doctor's advice",
      "Never stop diabetes medication without medical consultation",
      "Monitor blood sugar regularly",
      "Watch for hypoglycemia symptoms if on medication"
    ]
  },
  {
    id: "acne",
    name: "Skin Acne",
    keywords: ["acne", "pimple", "skin", "blemish", "breakout", "zit", "blackhead", "whitehead", "spots", "oily skin"],
    description: "Acne (Mukhadushika) involves excess Pitta and Kapha dosha with Ama accumulation. Internal purification is as important as external treatment.",
    remedies: [
      "Apply neem paste or neem oil mixed with turmeric on affected areas",
      "Use a face pack of multani mitti (fuller's earth) with rose water",
      "Apply fresh aloe vera gel directly on acne",
      "Mix turmeric, sandalwood, and rosewater into a face mask",
      "Steam the face to open pores, then apply neem paste"
    ],
    herbs: ["Neem", "Turmeric", "Manjistha", "Sandalwood (Chandan)", "Amla", "Lodhra"],
    diet: [
      "Reduce spicy, oily, and fried foods",
      "Eat a Pitta-pacifying diet: cooling foods, less sour and spicy",
      "Include fresh vegetables and fruits",
      "Drink at least 8-10 glasses of water daily",
      "Avoid dairy, especially milk, which can trigger acne"
    ],
    lifestyle: [
      "Wash face gently 2 times daily — not more",
      "Change pillowcases frequently",
      "Avoid touching face with unwashed hands",
      "Manage stress which worsens breakouts",
      "Practice regular Panchakarma-inspired cleansing"
    ],
    precautions: [
      "Severe cystic acne needs dermatologist treatment",
      "Do not squeeze or pop pimples — causes scarring",
      "Test new topical products on a small area first",
      "PCOS-related acne needs hormonal evaluation"
    ]
  },
  {
    id: "pcos",
    name: "PCOS (Wellness Tips)",
    keywords: ["pcos", "polycystic", "irregular periods", "hormones", "ovarian cyst", "pcod", "period problems", "hormonal imbalance"],
    description: "PCOS is addressed in Ayurveda through Artava Kshaya (decreased menstrual flow) and Kapha-Vata imbalance. Note: Always consult a gynecologist for diagnosis and treatment.",
    remedies: [
      "Take Shatavari powder with warm milk daily",
      "Drink Spearmint tea twice daily to reduce androgens naturally",
      "Take Triphala at bedtime to support detoxification",
      "Use Ashwagandha to balance hormones and reduce stress",
      "Apply warm sesame oil massage on the lower abdomen"
    ],
    herbs: ["Shatavari", "Ashwagandha", "Triphala", "Lodhra", "Shatapushpa (Fennel)", "Guduchi"],
    diet: [
      "Follow an anti-inflammatory, low GI diet",
      "Avoid refined carbohydrates and sugar",
      "Include phytoestrogen-rich foods: flaxseeds, sesame",
      "Reduce dairy if it worsens symptoms",
      "Include cruciferous vegetables: broccoli, cabbage"
    ],
    lifestyle: [
      "Exercise regularly — helps with insulin sensitivity",
      "Maintain healthy weight — even 5-10% weight loss improves PCOS",
      "Practice yoga asanas: Baddha Konasana, Supta Virasana",
      "Manage stress through yoga and meditation",
      "Sleep 7-9 hours — hormonal balance depends on it"
    ],
    precautions: [
      "Always consult a gynecologist for PCOS diagnosis and management",
      "Do not stop hormonal medications without medical advice",
      "PCOS increases risk of diabetes and heart disease — monitor regularly",
      "Get regular ultrasound and hormone panel checks"
    ]
  },
  {
    id: "immunity",
    name: "Low Immunity",
    keywords: ["immunity", "immune", "weak", "frequent illness", "low immunity", "getting sick", "boost immunity", "defense"],
    description: "Low immunity (Ojakshaya — depletion of Ojas) in Ayurveda is the fundamental cause of all disease. Building Ojas is the cornerstone of immunity.",
    remedies: [
      "Take Chyawanprash daily — a classic Ojas-building formula",
      "Drink Tulsi-Ginger-Turmeric tea daily",
      "Take Ashwagandha with warm milk and honey",
      "Use Triphala regularly for cleansing and antioxidant support",
      "Apply Nasya (nasal oiling) with sesame oil"
    ],
    herbs: ["Ashwagandha", "Tulsi", "Amla", "Giloy (Guduchi)", "Turmeric", "Shatavari"],
    diet: [
      "Eat fresh, seasonal, and wholesome foods",
      "Include Ojas-building foods: ghee, milk, dates, almonds, saffron",
      "Eat colorful fruits and vegetables for antioxidants",
      "Include probiotic foods: curd, buttermilk, fermented foods",
      "Avoid processed, canned, and leftover foods"
    ],
    lifestyle: [
      "Follow Dinacharya — a structured daily routine",
      "Sleep 7-9 hours daily — immunity is built during sleep",
      "Exercise moderately — excessive exercise depletes immunity",
      "Practice Pranayama daily to strengthen lung capacity",
      "Minimize chronic stress — it is the number one immune suppressor"
    ],
    precautions: [
      "Recurrent serious infections need medical evaluation",
      "Rule out autoimmune conditions if symptoms are severe",
      "Immunosuppressive conditions need specialist care",
      "Vaccinations are an important part of immunity"
    ]
  },
  {
    id: "headache",
    name: "Headache & Migraine",
    keywords: ["headache", "migraine", "head pain", "temple pain", "throbbing head", "head ache", "head hurts", "skull pain"],
    description: "Headache (Shirashoola) can involve all three doshas. Tension headaches are Vata-type, migraines are Pitta-type, and sinus headaches are Kapha-type.",
    remedies: [
      "Apply a paste of sandalwood powder and water on the forehead",
      "Inhale eucalyptus or peppermint essential oil",
      "Massage temples with Brahmi oil or sesame oil",
      "Drink Buttermilk (Takra) with cumin and ginger",
      "Apply a cool cloth soaked in lavender water to the forehead"
    ],
    herbs: ["Brahmi", "Shankhpushpi", "Ginger", "Peppermint", "Sandalwood"],
    diet: [
      "Stay well hydrated — dehydration is a common cause",
      "Avoid trigger foods: aged cheese, red wine, processed meats",
      "Eat regular meals — blood sugar drops cause headaches",
      "Reduce caffeine intake gradually if dependent",
      "Include magnesium-rich foods: dark leafy greens, nuts"
    ],
    lifestyle: [
      "Practice Nadi Shodhana pranayama to calm the nervous system",
      "Rest in a dark, quiet room during headache episodes",
      "Correct posture — poor posture causes tension headaches",
      "Practice regular sleep patterns",
      "Yoga and stretching for neck and shoulder tension relief"
    ],
    precautions: [
      "Sudden severe 'thunderclap' headache requires emergency care",
      "Headache with vision changes needs urgent attention",
      "Chronic daily headache needs neurological evaluation",
      "Headache after head injury must be evaluated immediately"
    ]
  },
  {
    id: "fatigue",
    name: "Fatigue & Low Energy",
    keywords: ["fatigue", "tired", "exhausted", "no energy", "weakness", "lethargy", "low energy", "burnout", "drained"],
    description: "Fatigue (Klama/Shrama) in Ayurveda results from Ojas depletion, weak Agni, or dosha imbalance. Chronic fatigue requires addressing root causes.",
    remedies: [
      "Take Ashwagandha with warm milk and honey daily",
      "Drink Chyawanprash in warm milk every morning",
      "Have Shatavari with milk and sugar for deep nourishment",
      "Soak 10 almonds overnight, peel and eat with warm milk in the morning",
      "Take a B12-rich diet with sesame seeds and dairy"
    ],
    herbs: ["Ashwagandha", "Shatavari", "Brahmi", "Amla", "Guduchi", "Bala"],
    diet: [
      "Eat regular nourishing meals — do not skip breakfast",
      "Include iron-rich foods: lentils, spinach, sesame, jaggery",
      "Stay hydrated — fatigue often equals dehydration",
      "Limit sugar and refined carbs which cause energy crashes",
      "Include complex carbohydrates for sustained energy"
    ],
    lifestyle: [
      "Prioritize 7-9 hours of quality sleep",
      "Practice gentle yoga and progressive exercise",
      "Take short rest breaks during the day (not long naps)",
      "Manage stress through meditation",
      "Spend time in nature and morning sunlight"
    ],
    precautions: [
      "Chronic fatigue lasting months needs thorough medical workup",
      "Rule out anemia, thyroid disorders, and diabetes",
      "Fatigue with unexplained weight loss needs investigation",
      "Chronic Fatigue Syndrome (ME/CFS) needs specialist care"
    ]
  }
];

export const generalWellness: AyurvedaCondition = {
  id: "general-wellness",
  name: "General Wellness",
  keywords: [],
  description: "General Ayurvedic wellness principles applicable to everyone, regardless of specific condition.",
  remedies: [
    "Start the day with warm water or herbal tea",
    "Practice oil pulling (Gandusha) with sesame oil for 10-15 minutes",
    "Do self-massage (Abhyanga) with warm sesame oil",
    "Take Triphala churna with warm water at bedtime",
    "Practice Pranayama for 10-15 minutes daily"
  ],
  herbs: ["Triphala", "Ashwagandha", "Tulsi", "Turmeric", "Amla", "Giloy"],
  diet: [
    "Eat freshly cooked, seasonal, and local foods",
    "Avoid overeating — eat to 75-80% of capacity",
    "Include all six tastes (Shadrasa) in meals",
    "Drink warm or room-temperature water throughout the day",
    "Avoid eating when emotionally disturbed"
  ],
  lifestyle: [
    "Wake up before sunrise (Brahma Muhurta) for optimal energy",
    "Maintain consistent sleep and wake times",
    "Practice 20-30 minutes of yoga daily",
    "Spend time in nature — it balances all doshas",
    "Follow Dinacharya (daily routine) for stability and health"
  ],
  precautions: [
    "Always consult a qualified Ayurvedic practitioner for personalized guidance",
    "Ayurveda is a complement to, not replacement for, modern medicine",
    "Individual constitution (Prakriti) affects what remedies are best for you",
    "Herbal remedies can interact with medications"
  ]
};

export const wellnessTips = [
  { tip: "Begin each morning with a glass of warm water to flush toxins and kickstart your digestion (Agni).", category: "Morning Routine", herbs: ["Ginger", "Lemon"] },
  { tip: "Practice Dinacharya — a mindful daily routine — to bring harmony to all three doshas and create lasting vitality.", category: "Daily Routine", herbs: ["Tulsi", "Ashwagandha"] },
  { tip: "Oil pulling with sesame oil for 15 minutes each morning strengthens gums, whitens teeth, and supports oral-systemic health.", category: "Oral Health", herbs: ["Sesame", "Neem"] },
  { tip: "Eat your largest meal at midday when your digestive fire (Agni) is at its strongest, aligned with the sun.", category: "Diet & Digestion", herbs: ["Ginger", "Cumin", "Turmeric"] },
  { tip: "Self-massage (Abhyanga) with warm sesame oil before bathing calms Vata, improves circulation, and nourishes the skin.", category: "Body Care", herbs: ["Sesame", "Brahmi", "Ashwagandha"] },
  { tip: "Triphala taken at bedtime with warm water is a gentle daily detox that supports digestion, eyesight, and longevity.", category: "Detox", herbs: ["Haritaki", "Bibhitaki", "Amalaki"] },
  { tip: "Sunlight exposure in the morning (before 9 AM) for 15 minutes supports vitamin D, mood, and circadian balance.", category: "Lifestyle", herbs: ["Turmeric", "Saffron"] },
  { tip: "Practice Nadi Shodhana (alternate nostril breathing) for 10 minutes daily to balance the nervous system and calm the mind.", category: "Breathwork", herbs: ["Brahmi", "Shankhpushpi"] },
  { tip: "Spice your food with turmeric, ginger, cumin, and coriander daily — they are powerful medicines hiding in your kitchen.", category: "Kitchen Medicine", herbs: ["Turmeric", "Ginger", "Cumin", "Coriander"] },
  { tip: "Chyawanprash, a traditional Ayurvedic superfood jam, taken daily with warm milk boosts immunity and builds Ojas (vital energy).", category: "Immunity", herbs: ["Amla", "Ashwagandha", "Shatavari"] }
];
